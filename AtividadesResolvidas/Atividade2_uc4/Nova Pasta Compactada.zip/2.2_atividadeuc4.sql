/*2. Crie uma stored function que receba id de funcionário,
 data inicial
e data final 
e retorne a comissão total desse funcionário no período indicado. 
No script, inclua o código de criação e uma chamada à function*/
select * from funcionario;
select* from venda;
select* from item_venda;
select * from cargo;-- vendedor com id = 2 e supervisor vendas id= 4 possuem comissao 10%--
select v.valor_total, f.cargo_id, c.comissao
from venda as v inner join funcionario as f on( v.funcionario_id=f.id)
           inner join cargo as c on ( f.cargo_id=c.id)
where
f.id=3;


DROP function  f_comissao_func ;
 
DELIMITER //
create function  f_comissao_func(id_funcionario int, datai datetime, dataf datetime) returns float deterministic
begin
	declare v_valor_total decimal(9,2);
    declare v_comissao float;
    declare datai datetime;
    declare dataf datetime;
select v.valor_total, c.comissao
	into v_valor_total, v_comissao
from venda as v inner join funcionario as f on( v.funcionario_id=f.id)
           inner join cargo as c on ( f.cargo_id=c.id)
where
f.id=id_funcionario
and    v.data between datai and dataf;

return sum(v_valor_total*v_comissao);
end//
DELIMITER ;
select f_comissao_func(6, '2019-01-08 10:10:00', '2022-01-13 12:01:00');
